﻿using System;
using System.Collections.Generic;
using System.Linq;
 

    class PointInTriangle
    {
        static void Main()
        {
            Console.WriteLine("Three points make triangle is point P in triangle ?");
            Console.WriteLine();
 
            //  triangle points
            Point first = new Point(0,0);
            Point second = new Point(0, 3);
            Point third = new Point(4, 0);

            // check points
            Point point = new Point(1, 1);  // Must be in
            //Point point = new Point(4, 4); // Must be out
 
            //  find outermost coordinates of the triangle
            double minX = Math.Min(Math.Min(first.X,second.X),third.X);
            double maxX = Math.Max(Math.Max(first.X,second.X),third.X);
 
            double minY = Math.Min(Math.Min(first.Y,second.Y),third.Y);
            double maxY = Math.Max(Math.Max(first.Y,second.Y),third.Y);
 
            //  check if the point is in the triangle or not
            bool inTriangle = minX < point.X && point.X < maxX && minY < point.Y && point.Y < maxY;
            Console.Write(" point {0} is in triangle {1}, {2}, {3}-> {4}", point, first, second, third,inTriangle);
            Console.WriteLine();
        }
    }

 
