﻿// Storage helpers
(function () {
    if (!Storage.prototype.setObject) {
        Storage.prototype.setObject = function (key, obj) {
            this.setItem(key, JSON.stringify(obj));
        }
    }

    if (!Storage.prototype.getObject) {
        Storage.prototype.getObject = function (key) {
            return JSON.parse(this.getItem(key));
        }
    }
}());

// Events shim
function attachEventHandler(element, eventType, eventHandler, useCapture) {

    useCapture = useCapture || false;

    if (!element) {
        return;
    }

    if (document.addEventListener) {
        element.addEventListener(eventType, eventHandler, useCapture);
    }
    else if (document.attachEvent) {
        element.attachEvent("on" + eventType, eventHandler);
    }
    else {
        element['on' + eventType] = eventHandler;
    }
}

// UI controls
var controls = (function () {

    // Escape most common HTML special characters
    function escapeHtml(unsafe) {
        return unsafe
             .replace(/&/g, "&amp;")
             .replace(/</g, "&lt;")
             .replace(/>/g, "&gt;")
             .replace(/"/g, "&quot;")
             .replace(/'/g, "&#039;");
    }

    // Initialize image gallery
    function getImageGallery(element) {

        var galleryElement = document.getElementById(element);

        var albumElementTpl = document.createElement('li');

        // Album class
        function Album(title, albumElement) {

            var albums = [];
            var images = [];

            this.addAlbum = function (title) {
                var albumElement = albumElementTpl.cloneNode(true);
                var newAlbum = new Album(title, albumElement);

                albums.push(newAlbum);

                return newAlbum;
            }

            this.addImage = function (title, src) {
                images.push(new Image(title, src));
            }

            // Render Album element
            this.render = function () {
                while (albumElement.firstChild) {
                    albumElement.removeChild(albumElement.firstChild);
                }

                // Render title if any
                if (title) {
                    var titleElement = document.createElement('a');
                    titleElement.innerHTML = escapeHtml(title);
                    titleElement.href = '#';
                    titleElement.setAttribute('data-gallerytitle', true);

                    albumElement.appendChild(titleElement);
                }

                // Render images
                if (images.length > 0) {
                    var imagesList = document.createElement('ul');
                    imagesList.className = 'gallery-images';

                    // Hide images list if current album is not the main gallery element
                    if (albumElement !== galleryElement) {
                        imagesList.style.display = "none";
                    }

                    for (var i = 0; i < images.length; i += 1) {
                        imagesList.appendChild(images[i].render());
                    }

                    albumElement.appendChild(imagesList);
                }

                // Render albums
                if (albums.length > 0) {

                    // Sort button
                    var sortButton = document.createElement('a');
                    sortButton.href = '#';
                    sortButton.className = 'gallery-sort';
                    sortButton.innerHTML = 'Toggle Sort';
                    sortButton.setAttribute('data-gallerysort', true);

                    // Hide sort button if current album is not the main gallery element
                    if (albumElement !== galleryElement) {
                        sortButton.style.display = "none";
                    }

                    albumElement.appendChild(sortButton);


                    var albumsList = document.createElement('ul');
                    albumsList.className = 'gallery-albums';

                    // Hide albums list if current album is not the main gallery element
                    if (albumElement !== galleryElement) {
                        albumsList.style.display = "none";
                    }

                    for (var i = 0; i < albums.length; i += 1) {
                        albumsList.appendChild(albums[i].render());
                    }

                    albumElement.appendChild(albumsList);

                }

                return albumElement;
            }

            this.serialize = function () {

                var imagesData = [];
                for (var i = 0; i < images.length; i += 1) {
                    imagesData.push(images[i].serialize());
                }

                var albumsData = [];
                for (var i = 0; i < albums.length; i += 1) {
                    albumsData.push(albums[i].serialize());
                }

                var data = {
                    title: title,
                    images: imagesData,
                    albums: albumsData
                };

                return data;
            }
        }

        // Image class
        function Image(title, src) {

            var listElement = document.createElement('li');

            var titleElement = document.createElement('h4');
            titleElement.innerHTML = title;
            listElement.appendChild(titleElement);

            var imgElement = document.createElement('img');
            listElement.appendChild(imgElement);

            imgElement.alt = title;
            imgElement.src = src;
            imgElement.title = title;

            // Render image
            this.render = function () {
                return listElement;
            }

            this.serialize = function () {
                var data = {
                    title: title,
                    src: src
                }

                return data;
            }
        }

        gallery = new Album(null, galleryElement);

        attachEventHandler(galleryElement, "click", toggleAlbumListener, false);
        attachEventHandler(galleryElement, "click", toggleSortListener, false);
        attachEventHandler(galleryElement, "click", toggleImageListener, false);

        return gallery;

    }

    // Build image gallery from serialized data
    function buildImageGallery(element, data) {
        var gallery = getImageGallery(element);

        buildImageGalleryElements(gallery, data);

        return gallery;
    }

    // Recursive build gallery elements
    function buildImageGalleryElements(gallery, data) {

        for (var i = 0; i < data.images.length; i += 1) {
            gallery.addImage(data.images[i].title, data.images[i].src);
        }


        for (var i = 0; i < data.albums.length; i += 1) {
            var album = gallery.addAlbum(data.albums[i].title);
            buildImageGalleryElements(album, data.albums[i]);
        }

    }

    // Toggle album
    var toggleAlbumListener = function (e) {
        e = e || window.event;

        if (!(e.target instanceof HTMLAnchorElement)) {
            return;
        }

        if (!e.target.getAttribute('data-gallerytitle')) {
            return;
        }

        e.stopPropagation();
        e.preventDefault();

        // Iterate siblings and toggle display property
        var nextSibling = e.target;
        while (nextSibling = nextSibling.nextElementSibling) {
            if (nextSibling.style.display == "none") {
                nextSibling.style.display = "";
            } else {
                nextSibling.style.display = "none";
            }
        }

    };

    // Sort listener
    var toggleSortListener = function (e) {
        e = e || window.event;

        if (!(e.target instanceof HTMLAnchorElement)) {
            return;
        }

        if (!e.target.getAttribute('data-gallerysort')) {
            return;
        }

        e.stopPropagation();
        e.preventDefault();

        var albumsList = e.target.nextElementSibling;

        if (!albumsList) {
            return;
        }

        var albumChilds = albumsList.childNodes;

        var albumsArray = [];
        for (var i = 0, len = albumChilds.length; i < len; i += 1) {
            albumsArray.push(albumChilds[i]);
        }

        var sortOrder = albumsList.getAttribute('data-sorted');

        if (sortOrder != 'asc') {
            albumsArray.sort(function (x, y) {
                return x.firstChild.innerHTML > y.firstChild.innerHTML ? 1 : x.firstChild.innerHTML < y.firstChild.innerHTML ? -1 : 0;
            });
            albumsList.setAttribute('data-sorted', 'asc');
            e.target.className = 'sorted-asc';
        } else {
            albumsArray.sort(function (x, y) {
                return x.firstChild.innerHTML < y.firstChild.innerHTML ? 1 : x.firstChild.innerHTML > y.firstChild.innerHTML ? -1 : 0;
            });
            albumsList.setAttribute('data-sorted', 'desc');
            e.target.className = 'sorted-desc';

        }

        while (albumsList.firstChild) {
            albumsList.removeChild(albumsList.firstChild);
        }

        for (var i = 0; i < len; i++) {
            albumsList.appendChild(albumsArray[i]);
        }
    };

    // Enlarge image
    var toggleImageListener = function (e) {

        if (!(e.target instanceof HTMLImageElement)) {
            return;
        }

        e.stopPropagation();
        e.preventDefault();

        var largeImage = e.target.cloneNode(true);

        largeImage.className = "gallery-large-image";
        largeImage.style.display = "block";
        largeImage.style.position = "absolute";
        largeImage.style.top = e.clientY + "px";
        largeImage.style.left = e.clientX + "px";
        largeImage.width = e.target.clientWidth * 2;

        document.body.appendChild(largeImage);
    }

    // Gallery repository
    var galleryRepository = (function () {

        this.load = function (key) {
            var obj = localStorage.getObject(key);
            return obj;
        }

        this.save = function (key, obj) {
            localStorage.setObject(key, obj);
        }

        return {
            load: load,
            save: save
        }
    })();

    // Close large images capturing click event

    attachEventHandler(document.body, "click", function (e) {
        e = e || window.event;

        if (e.target instanceof HTMLImageElement) {
            if (e.target.className == "gallery-large-image") {
                e.preventDefault();
                e.stopPropagation();
                return;
            }
        }

        var previousLargeImages = document.getElementsByClassName("gallery-large-image");

        if (previousLargeImages.length > 0) {
            while (previousLargeImages.length > 0) {
                previousLargeImages[0].parentNode.removeChild(previousLargeImages[0]);
            }
        }

    }, true);

    // Expose interface
    return {
        getImageGallery: getImageGallery,
        getImageGalleryRepository: function () {
            return galleryRepository;
        },
        buildImageGallery: buildImageGallery
    }

})();
