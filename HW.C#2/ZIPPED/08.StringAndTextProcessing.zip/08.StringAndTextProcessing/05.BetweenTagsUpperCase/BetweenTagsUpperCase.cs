﻿using System;
using System.Text;
using System.Collections.Generic;
    class BetweenTagsUpperCase
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter text with tags");
            string text = Console.ReadLine();
            
        }
    }

