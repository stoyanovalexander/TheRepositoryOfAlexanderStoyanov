﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _4.PersonInfo
{
    class TestPersonInfo
    {
        static void Main(string[] args)
        {
            Person hurencho = new Person("Huren Chkr",null);
            Console.WriteLine(hurencho);
        }
    }
}
