﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace _1To3.StudentInfo
{
    public enum University
    {
        UNSS,
        TelerikUniversity,
        NewBulgarianUniversity
    }

}