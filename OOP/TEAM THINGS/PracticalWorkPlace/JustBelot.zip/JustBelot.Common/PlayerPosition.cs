﻿namespace JustBelot.Common
{
    public enum PlayerPosition
    {
        South = 0,
        East = 1,
        North = 2,
        West = 3,
    }
}
