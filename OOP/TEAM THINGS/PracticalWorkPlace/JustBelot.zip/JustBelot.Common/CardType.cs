﻿namespace JustBelot.Common
{
    public enum CardType
    {
        Ace = 7,
        King = 6,
        Queen = 5,
        Jack = 4,
        Ten = 3,
        Nine = 2,
        Eight = 1,
        Seven = 0,
    }
}
