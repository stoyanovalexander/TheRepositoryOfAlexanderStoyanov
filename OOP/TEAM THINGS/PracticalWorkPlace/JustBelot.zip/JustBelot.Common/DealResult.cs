﻿namespace JustBelot.Common
{
    public struct DealResult
    {
    }
}
