﻿namespace JustBelot.Common
{
    public struct Declaration
    {
    }
}
