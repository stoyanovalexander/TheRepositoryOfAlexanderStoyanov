﻿namespace JustBelot.Common
{
    public enum ContractType
    {
        Clubs = 1, // ♣
        Diamonds = 2, // ♦
        Hearts = 3, // ♥
        Spades = 4, // ♠
        NoTrumps = 5,
        AllTrumps = 6,
    }
}
