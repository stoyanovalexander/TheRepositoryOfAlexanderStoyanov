﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JustBelot.UI
{
    public static class Settings
    {
        public const string ProgramName = "JustBelot 1.0.20130225";
    }
}
