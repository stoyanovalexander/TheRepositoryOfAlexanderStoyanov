﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirmOrganization
{
    public class Worker
    {
        public int YearsInTheFirm { get; set; }
        public int WorkHoursLastMounth { get; set; }
        public string section { get; set; }
        public string TypeMachines { get; set; }

        
    }
}
