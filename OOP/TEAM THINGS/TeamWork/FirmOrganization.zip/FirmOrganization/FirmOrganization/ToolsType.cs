﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FirmOrganization
{
    public class ToolsType
    {
        public string NameOfTheType { get; set; }
        public int NumberOfTools { get; set; }
        public List<Tool> Tools { get; set; }
    }
}
