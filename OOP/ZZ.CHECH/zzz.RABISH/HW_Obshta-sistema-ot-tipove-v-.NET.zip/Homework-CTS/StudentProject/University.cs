﻿namespace StudentProject
{
    public enum University
    {
        None,
        TU,
        SU,
        NBU,
        UASG,
        UNSS,
        Telerik
    }
}
