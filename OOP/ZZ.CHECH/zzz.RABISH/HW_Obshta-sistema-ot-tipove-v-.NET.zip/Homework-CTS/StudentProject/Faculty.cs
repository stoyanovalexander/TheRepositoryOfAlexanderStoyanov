﻿namespace StudentProject
{
    public enum Faculty
    {
        None,
        Informatics,
        Economy,
        Literature
    }
}
