﻿namespace StudentProject
{
    public enum Specialty
    {
        None,
        SoftwareEngineer,
        BussinessMan,
        Lawyer,
        SalesMan
    }
}
