﻿using System;

namespace Bank
{
    enum AccountTypes
    {
        individual = 1,
        company = 2,
    }
}
