﻿// 1. Write an expression that checks if given integer is odd or even.

var userInput = 3;
var oddOrEven;
oddOrEven = ((userInput % 2) == 0) ? 'Even' : 'Odd';
console.log(oddOrEven);