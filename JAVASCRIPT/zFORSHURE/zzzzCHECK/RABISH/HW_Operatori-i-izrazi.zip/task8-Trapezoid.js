﻿// 8. Write an expression that calculates trapezoid's area by given sides a and b and height h.

var userInput = {a: 3, b: 5, h: 2};
var trapArea = ((userInput.a + userInput.b)/2)*userInput.h;
console.log('Area: ' + trapArea + ' square units');