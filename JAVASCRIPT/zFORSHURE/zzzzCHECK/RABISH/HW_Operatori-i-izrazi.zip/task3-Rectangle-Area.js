﻿// 3. Write an expression that calculates rectangle’s area by given width and height.

var userInput = {width: 3, height: 5};
var area = userInput.width * userInput.height;
console.log(area + ' square units');